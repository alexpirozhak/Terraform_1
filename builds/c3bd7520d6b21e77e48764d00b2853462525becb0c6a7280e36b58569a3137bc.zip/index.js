const AWS = require("aws-sdk");
const dynamodb = new AWS.DynamoDB({
    region: process.env.AWS_REGION,
    apiVersion: "2012-08-10"
});

exports.handler = (event, context, callback) => {
    const params = {
        TableName: process.env.TABLE_COURSES
    };
    dynamodb.scan(params, (err, data) => {
        if (err) {
            console.log(err);
            callback(err);
        } else {
            const courses = data.Items.map(item => {
                return {
                    id: item.id && item.id.S ? item.id.S : null,
                    title: item.title && item.title.S ? item.title.S : null,
                    authorId: item.authorId && item.authorId.S ? item.authorId.S : null,
                    length: item.length && item.length.S ? item.length.S : null,
                    category: item.category && item.category.S ? item.category.S : null,
                    watchHref: item.watchHref && item.watchHref.S ? item.watchHref.S : null
                };
            });
            callback(null, { courses });
        }
    });
};