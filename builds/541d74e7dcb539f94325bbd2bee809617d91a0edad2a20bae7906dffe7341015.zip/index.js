const AWS = require("aws-sdk");
const dynamodb = new AWS.DynamoDB({
    region: process.env.AWS_REGION || "eu-central-1",
    apiVersion: "2012-08-10"
});

exports.handler = (event, context, callback) => {
    console.log("Received event:", JSON.stringify(event, null, 2));
    console.log("Environment variables:", process.env);

    // Перевірка, чи передано TABLE_NAME
    const tableName = process.env.TABLE_NAME;
    if (!tableName) {
        console.error("TABLE_NAME is not defined");
        return callback(new Error("TABLE_NAME environment variable is missing"));
    }

    // Парсимо тіло запиту
    let body;
    try {
        body = JSON.parse(event.body);
    } catch (error) {
        console.error("Failed to parse event.body:", error);
        return callback(new Error("Invalid request body"));
    }

    // Перевірка обов’язкових полів
    if (!body.title || !body.authorId || !body.length || !body.category) {
        console.error("Missing required fields:", body);
        return callback(new Error("Missing required fields: title, authorId, length, category"));
    }

    const params = {
        TableName: tableName,
        Item: {
            id: { S: context.awsRequestId }, // Унікальний ID для нового курсу
            title: { S: body.title },
            authorId: { S: body.authorId },
            length: { S: body.length },
            category: { S: body.category },
            watchHref: { S: body.watchHref || "" }
        }
    };

    dynamodb.putItem(params, (err, data) => {
        if (err) {
            console.error("DynamoDB error:", err);
            return callback(err);
        }
        console.log("Successfully saved course:", data);
        callback(null, {
            statusCode: 200,
            body: JSON.stringify({ message: "Course saved successfully", id: context.awsRequestId }),
            headers: {
                "Access-Control-Allow-Origin": "*" // Додаємо CORS-заголовок
            }
        });
    });
};